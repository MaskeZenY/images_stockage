This recource makes you add custom markers for fivem.

-- Credits for original post: @ahmed608 (Konar)

Preview: 

<a href='https://postimg.cc/wy58cJBZ' target='_blank'><img src='https://i.postimg.cc/wy58cJBZ/Ds-Studio-custom-markers.jpg' border='0' alt='Ds-Studio-custom-markers'/></a>
